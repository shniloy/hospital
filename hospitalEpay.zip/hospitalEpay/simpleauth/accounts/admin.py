from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
from django.urls import path
from django.shortcuts import render, redirect, get_object_or_404
from django import forms
from .models import Invoice
from django.utils.html import format_html

# Invoice Form for admin
class InvoiceForm(forms.ModelForm):
    class Meta:
        model = Invoice
        fields = ['service_name', 'price']

# Custom UserAdmin to filter non-superusers and add the "Create Invoice" button
class CustomUserAdmin(UserAdmin):
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('<id>/create_invoice/', self.admin_site.admin_view(self.create_invoice), name='create-invoice'),
        ]
        return custom_urls + urls

    def create_invoice(self, request, id):
        user = get_object_or_404(User, pk=id)
        if request.method == 'POST':
            form = InvoiceForm(request.POST)
            if form.is_valid():
                invoice = form.save(commit=False)
                invoice.user = user
                invoice.save()
                return redirect(f'/admin/auth/user/{id}/change/')
        else:
            form = InvoiceForm()

        return render(request, 'admin/create_invoice.html', {'form': form, 'user': user})

    # Filtering only non-superusers
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.filter(is_superuser=False)

    # Add 'Create Invoice' button on user detail page
    def change_view(self, request, object_id, form_url='', extra_context=None):
        extra_context = extra_context or {}
        extra_context['create_invoice_url'] = f'/admin/auth/user/{object_id}/create_invoice/'
        return super().change_view(request, object_id, form_url, extra_context=extra_context)

    # Display 'Create Invoice' link next to the user's name
    def create_invoice_link(self, obj):
        return format_html(f'<a href="/admin/auth/user/{obj.id}/create_invoice/">Create Invoice</a>')
    create_invoice_link.short_description = 'Invoice'

    # Adding the invoice creation link to the list display
    list_display = ['username', 'email', 'create_invoice_link']

# Register the customized UserAdmin
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)
