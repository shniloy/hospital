from django.urls import path
from . import views
from .views import user_invoices_view, make_payment_view  # Import the views

urlpatterns = [
    path('', views.main_page, name='main_page'),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('home/', views.home_view, name='home'),
    path('logout/', views.logout_view, name='logout'),
    path('invoices/', user_invoices_view, name='user_invoices'),
    path('invoices/make_payment/<int:invoice_id>/', make_payment_view, name='make_payment'),
]
