from django.db import models
from django.contrib.auth.models import User

class Invoice(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    service_name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    is_paid = models.BooleanField(default=False)  # Add this field

    def __str__(self):
        return f"{self.service_name} - {self.price} ({'Paid' if self.is_paid else 'Unpaid'})"
