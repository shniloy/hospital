import logging
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from .models import Invoice
from sslcommerz import SSLCOMMERZ


# Initialize SSLCommerz
sslcommerz = SSLCOMMERZ(
    store_id='niyam6412dc52e1e89',  # Replace with your Store ID
    store_pass='niyam6412dc52e1e89@ssl',  # Replace with your Store Password
    is_sandbox=True,  # Set to False in production
)

# Main page view (Login/Signup option)
def main_page(request):
    if request.user.is_authenticated:
        return redirect('home')
    return render(request, 'accounts/main_page.html')

# Signup view
def signup_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()

    return render(request, 'accounts/signup.html', {'form': form})

# Login view
def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()

    return render(request, 'accounts/login.html', {'form': form})

# Logout view
def logout_view(request):
    logout(request)
    return redirect('main_page')

# Home page view (Only for logged-in users)
@login_required
def home_view(request):
    invoices = Invoice.objects.filter(user=request.user)
    return render(request, 'accounts/home.html', {'user': request.user, 'invoices': invoices})

# View for logged-in users to see their invoices
@login_required
def user_invoices_view(request):
    invoices = Invoice.objects.filter(user=request.user)
    return render(request, 'user_invoices.html', {'invoices': invoices})

# View to make payment for an invoice
@login_required
def make_payment_view(request, invoice_id):
    invoice = get_object_or_404(Invoice, id=invoice_id, user=request.user)

    if request.method == 'POST':
        # Prepare payment data
        payment_data = {
            'total_amount': invoice.price,
            'currency': 'BDT',
            'tran_id': str(invoice.id),  # Unique transaction ID
            'success_url': request.build_absolute_uri('/payment/success/'),
            'fail_url': request.build_absolute_uri('/payment/fail/'),
            'cancel_url': request.build_absolute_uri('/payment/cancel/'),
            'product_name': invoice.service_name,
            'product_category': 'Services',
            'product_profile': 'general',
            'customer_name': request.user.username,
            'customer_email': request.user.email,
            'customer_phone': '01700000000',  # Update this
            'customer_address': 'Customer Address',  # Update this
            'customer_city': 'Dhaka',
            'customer_country': 'Bangladesh',
        }

        # Make a request to SSLCommerz
        response_data = sslcommerz.payment_request(data=payment_data)

        if response_data.get('status') == 'success':
            # Redirect to SSLCommerz for payment
            return redirect(response_data['GatewayPageURL'])
        else:
            error_message = response_data.get('message', 'Payment initialization failed.')
            logging.error("Payment initialization failed: %s", response_data)
            return render(request, 'payment_error.html', {'error': error_message, 'full_response': response_data})

    return render(request, 'make_payment.html', {'invoice': invoice})

# Payment success view
def payment_success(request):
    invoice_id = request.GET.get('tran_id')  # Get transaction ID
    invoice = get_object_or_404(Invoice, id=invoice_id)

    # Mark invoice as paid
    invoice.is_paid = True
    invoice.save()

    return HttpResponse("Payment Successful! Invoice Paid.")

# Payment fail view
def payment_fail(request):
    return HttpResponse("Payment Failed.")

# Payment cancel view
def payment_cancel(request):
    return HttpResponse("Payment Cancelled.")
